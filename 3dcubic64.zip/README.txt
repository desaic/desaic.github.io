3D cubic structures at 64^3 resolution and their elastic parameters.
Each structure is stored in "id.bin".
Their parameters are listed in param_0.35.txt".

Each structure is stored in binary format
The first 3 ints are voxel resolution, which is always 64 64 64 for this data set.
The following bits signifies soft and rigid voxels.
It can be read using the following c++ function

void loadBinaryStructure(const std::string & filename,
  std::vector<int> & s,
  std::vector<int> & gridSize)
{
  int dim = 3;
  std::ifstream in(filename, std::ios::in | std::ios::binary);
  if (!in.good()){
    std::cout << "Cannot open input " << filename << "\n";
    in.close();
    return;
  }
  gridSize.clear();
  gridSize.resize(dim,0);
  int nCell = 1;
  for (int i = 0; i < dim; i++){
    in.read( (char*)(&gridSize[i]), sizeof(int) );
    nCell *= gridSize[i];
  }
  s.resize(nCell, 0);
  for (std::vector<bool>::size_type i = 0; i < nCell;){
    unsigned char aggr;
    in.read((char*)&aggr, sizeof(unsigned char));
    for (unsigned char mask = 1; mask > 0 && i < nCell; ++i, mask <<= 1)
      s[i] = (aggr & mask)>0;
  }
  in.close();
}

The first line in the plain text elastic parameters file contains
#structures #parameters
The following #structures lines containt elastic parameters for cubic structures in the following order
volume_fraction Young's_modulus Poisson's_ratio Shear_modulus
